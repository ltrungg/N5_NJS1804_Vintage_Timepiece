import React from "react";
import SignInComponent from "../components/authentication/SignIn";

export default function Signin() {
  return <SignInComponent />;
}
