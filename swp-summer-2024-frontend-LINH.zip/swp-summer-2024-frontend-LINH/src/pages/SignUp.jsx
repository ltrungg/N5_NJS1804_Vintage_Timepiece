import React from "react";
import SignUpComponent from "../components/authentication/SignUp";
export default function SignUp() {
  return <SignUpComponent />;
}
