import React from 'react'
import Contact from '../components/contact/ContactForm'
export default function ContactPage() {
  return (
    <div>
      <Contact/>
    </div>
  )
}
